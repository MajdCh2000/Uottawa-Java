public class Cashier {

    // Constant

    private static final String nl = System.getProperty( "line.separator" );

    // Instance variables

    private Queue<Customer> queue;
    private Customer currentCustomer;

    private int totalCustomerWaitTime;
    private int customersServed;
    private int totalItemsServed;

    // constructor

    public Cashier(){
        // Your code here.
    	this.totalCustomerWaitTime=0;
    	this.totalItemsServed=0;
    	this.totalItemsServed=0;
    	this.queue = new ArrayQueue<Customer>();
    	
    }

    public void addCustomer( Customer c ) {
        this.queue.enqueue(c);
    }

    public int getQueueSize() {
    	return queue.size();
    }
    public void serveCustomers( int currentTime){
     if(currentCustomer==null && queue.isEmpty()==true) {
    	 return;
     }
     if(currentCustomer==null) {
    	  this.currentCustomer=queue.dequeue();
    	  this.totalCustomerWaitTime=totalCustomerWaitTime+currentTime-currentCustomer.getArrivalTime();
      }
    	this.currentCustomer.serve();
    	if(currentCustomer.getNumberOfItems()==0) {
    		customersServed++;
    		this.totalItemsServed=totalItemsServed+currentCustomer.getNumberOfServedItems();
    		
    		currentCustomer=null;
    	}
    }
    public int getTotalCustomerWaitTime() {
    	return this.totalCustomerWaitTime;
    }
    public int getTotalItemsServed(){
    	return this.totalItemsServed;
    }
    public int getTotalCustomersServed() {
    	return this.customersServed;
    }
    public String toString() {

        StringBuffer results = new StringBuffer();

        results.append( "The total number of customers served is " );
        results.append( customersServed );
        results.append( nl );

        results.append( "The average number of items per customer was " );
        results.append( totalItemsServed / customersServed );
        results.append( nl );

        results.append( "The average waiting time (in seconds) was " );
        results.append( totalCustomerWaitTime / customersServed );
        results.append( nl );

        return results.toString();
    }
}