Student name: Majd Chantiri
Student number: 300217475
Course code: ITI 1121
Lab section: B-2

This archive contains the 5 files of lab 8, that is, this file (README.txt),
plus Queue.java, ArrayQueue.java, Customer.java, Cashier.java.
