public class Q3_SquareArray{

	public static int[] createArray(int size) {

		int[] theArray;

		theArray = new int[size];

		for(int i = 0; i < size; i++){
			theArray[i] = i*i;
		}

		return theArray;
	}

	public static void main(String[] args){

		
		int[] theArray;

		theArray = createArray(13);

		for(int i = 0; i < theArray.length; i++){
			System.out.println("The square of " + i + " is: " + theArray[i]);
		}

	}
}
