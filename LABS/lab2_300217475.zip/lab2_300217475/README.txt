Student name: Majd Chantiri
Student number: 300217475
Course code: ITI 1121
Lab section: B-2

This archive contains the 3 files of the lab 2, that is, this file (README.txt),
the files Combination.java and DoorLock.java.