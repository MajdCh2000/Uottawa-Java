Student name: Majd Chantiri
Student number: 300217475
Course code: ITI 1121
Lab section: B-2

This archive contains the 6 files of the lab 1, that is, this file (README.txt),
the files ArrayStack.java, Dictionary.java, DynamicArrayStack.java, Map.java, Stack.java.