public class ArrayStack<E> implements Stack<E> {

    // Instance variables

    private E[] elems;  // Used to store the elements of this ArrayStack
    private int top;    // Designates the first free cell

    @SuppressWarnings( "unchecked" )

    // Constructor

    public ArrayStack( int capacity ) {
        elems = (E[]) new Object[ capacity ];
        top = 0;
    }

    // Returns true if this ArrayStack is empty

    public boolean isEmpty() {

        return ( top == 0 );
    }

    // Returns the top element of this ArrayStack without removing it

    public E peek() {

        // pre-conditions: ! isEmpty()

        return elems[ top-1 ];
    }

    // Removes and returns the top element of this stack

    public E pop() {

        
        E saved = elems[ --top ];

        elems[ top ] = null; // scrub the memory!

        return saved;
    }


    public void push( E element ) {


        elems[ top++ ] = element;
    }

    @SuppressWarnings( "unchecked" )

    public void clear() {

        while (!isEmpty()) {
          pop();
        }

        top = 0;
    }

}
