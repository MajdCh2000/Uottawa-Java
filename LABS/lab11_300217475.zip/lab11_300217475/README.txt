Student name: Majd Chantiri
Student number: 300217475
Course code: ITI 1121
Lab section: B-2

This archive contains the 5 files of the lab 11, that is, this file (README.txt),
the files BinarySearchTree.java, BitList.java, Iterative.java, Iterator.java.